-- Fictional sample data for SJSU SafeMap. These are not real incident reports.
CREATE TABLE IF NOT EXISTS public.safety_reports (
  id text PRIMARY KEY,
  is_demo boolean NOT NULL DEFAULT true,
  reporter_type text NOT NULL,
  privacy_mode text NOT NULL,
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  location_source text NOT NULL,
  location_confirmed boolean NOT NULL DEFAULT true,
  location text NOT NULL,
  incident_date text NOT NULL,
  incident_time text NOT NULL,
  description text NOT NULL,
  incident_type text NOT NULL,
  moderation_status text NOT NULL,
  priority_status text NOT NULL,
  moderation_reason text NOT NULL,
  submitted_at text NOT NULL
);

INSERT INTO public.safety_reports
(id, is_demo, reporter_type, privacy_mode, latitude, longitude, location_source, location_confirmed, location, incident_date, incident_time, description, incident_type, moderation_status, priority_status, moderation_reason, submitted_at)
VALUES
('DEMO-001', true, 'student', 'anonymous', 37.3365, -121.8806, 'manual', true, 'Student Union', '2026-09-08', '14:20', 'Fictional example: a backpack was reported missing after a study session.', 'Lost Property', 'Pending review', 'Normal', 'Fictional demonstration record; not reviewed.', '2026-09-08T14:20:00'),
('DEMO-002', true, 'resident', 'anonymous', 37.3355, -121.8840, 'manual', true, 'MLK Library', '2026-09-10', '18:45', 'Fictional example: repeated unwanted messages were reported near the library.', 'Harassing Communications', 'Pending review', 'High', 'Fictional demonstration record; not reviewed.', '2026-09-10T18:45:00'),
('DEMO-003', true, 'student', 'anonymous', 37.3339, -121.8907, 'manual', true, 'Paseo de San Antonio', '2026-09-12', '12:10', 'Fictional example: a bicycle was reported missing from a public rack.', 'Theft', 'Pending review', 'Normal', 'Fictional demonstration record; not reviewed.', '2026-09-12T12:10:00'),
('DEMO-004', true, 'resident', 'anonymous', 37.3367, -121.8937, 'manual', true, 'San Pedro Square', '2026-09-13', '20:30', 'Fictional example: a visitor described a suspicious payment request.', 'Fraud', 'Pending review', 'Normal', 'Fictional demonstration record; not reviewed.', '2026-09-13T20:30:00'),
('DEMO-005', true, 'student', 'anonymous', 37.3305, -121.8864, 'manual', true, 'South First Street', '2026-09-15', '09:15', 'Fictional example: damage to a public-facing fixture was noticed.', 'Vandalism', 'Pending review', 'Low', 'Fictional demonstration record; not reviewed.', '2026-09-15T09:15:00'),
('DEMO-006', true, 'resident', 'anonymous', 37.3330, -121.8835, 'manual', true, 'Washington Square', '2026-09-16', '16:05', 'Fictional example: a pathway light was reported out.', 'Other Safety Concern', 'Pending review', 'Low', 'Fictional demonstration record; not reviewed.', '2026-09-16T16:05:00'),
('DEMO-007', true, 'student', 'anonymous', 37.3310, -121.8769, 'manual', true, 'Campus Village', '2026-09-18', '22:40', 'Fictional example: an item was reported missing from a parked vehicle.', 'Theft from Vehicle', 'Pending review', 'High', 'Fictional demonstration record; not reviewed.', '2026-09-18T22:40:00'),
('DEMO-008', true, 'resident', 'anonymous', 37.3363, -121.8882, 'manual', true, 'Downtown transit area', '2026-09-19', '07:50', 'Fictional example: a wallet was reported missing after a transit trip.', 'Lost Property', 'Pending review', 'Normal', 'Fictional demonstration record; not reviewed.', '2026-09-19T07:50:00'),
('DEMO-009', true, 'student', 'anonymous', 37.3350, -121.8786, 'manual', true, 'SJSU east campus walkway', '2026-09-21', '11:25', 'Fictional example: damage to a parked vehicle was described.', 'Vandalism of Vehicle', 'Pending review', 'Normal', 'Fictional demonstration record; not reviewed.', '2026-09-21T11:25:00'),
('DEMO-010', true, 'resident', 'anonymous', 37.3326, -121.8803, 'manual', true, 'Paseo de San Carlos', '2026-09-22', '15:35', 'Fictional example: a student reported a suspicious account notification.', 'Identity Theft', 'Pending review', 'High', 'Fictional demonstration record; not reviewed.', '2026-09-22T15:35:00')
ON CONFLICT (id) DO UPDATE SET
  is_demo = EXCLUDED.is_demo,
  reporter_type = EXCLUDED.reporter_type,
  privacy_mode = EXCLUDED.privacy_mode,
  latitude = EXCLUDED.latitude,
  longitude = EXCLUDED.longitude,
  location_source = EXCLUDED.location_source,
  location_confirmed = EXCLUDED.location_confirmed,
  location = EXCLUDED.location,
  incident_date = EXCLUDED.incident_date,
  incident_time = EXCLUDED.incident_time,
  description = EXCLUDED.description,
  incident_type = EXCLUDED.incident_type,
  moderation_status = EXCLUDED.moderation_status,
  priority_status = EXCLUDED.priority_status,
  moderation_reason = EXCLUDED.moderation_reason,
  submitted_at = EXCLUDED.submitted_at;
