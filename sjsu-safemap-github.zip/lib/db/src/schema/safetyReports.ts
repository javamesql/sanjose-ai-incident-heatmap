import { boolean, doublePrecision, pgTable, text } from "drizzle-orm/pg-core";

export const safetyReportsTable = pgTable("safety_reports", {
  id: text("id").primaryKey(),
  isDemo: boolean("is_demo").notNull().default(true),
  reporterType: text("reporter_type").notNull(),
  privacyMode: text("privacy_mode").notNull(),
  latitude: doublePrecision("latitude").notNull(),
  longitude: doublePrecision("longitude").notNull(),
  locationSource: text("location_source").notNull(),
  locationConfirmed: boolean("location_confirmed").notNull().default(true),
  location: text("location").notNull(),
  incidentDate: text("incident_date").notNull(),
  incidentTime: text("incident_time").notNull(),
  description: text("description").notNull(),
  incidentType: text("incident_type").notNull(),
  moderationStatus: text("moderation_status").notNull(),
  priorityStatus: text("priority_status").notNull(),
  moderationReason: text("moderation_reason").notNull(),
  submittedAt: text("submitted_at").notNull(),
});

export type SafetyReport = typeof safetyReportsTable.$inferSelect;