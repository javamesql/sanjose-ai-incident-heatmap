import React, { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { getListSafetyReportsQueryKey, useListSafetyReports } from '@workspace/api-client-react';
import { SAMPLE_REPORTS, type ReportRecord } from '../data/reports';
import { loadReports, saveReport } from '../data/reportStore';
export type { ReportRecord, ModerationStatus, PriorityStatus } from '../data/reports';
export const initialRecord = SAMPLE_REPORTS[0];

type AppContextType = {
  isAuthenticated: boolean;
  login: (email: string, pass: string) => boolean;
  logout: () => void;
  record: ReportRecord;
  setRecord: (val: ReportRecord) => void;
  draftRecord: ReportRecord;
  setDraftRecord: (val: ReportRecord) => void;
  editing: boolean;
  setEditing: (val: boolean) => void;
  reports: ReportRecord[];
  selectRecord: (id: string) => void;
  persistRecord: (val: ReportRecord) => Promise<void>;
  storageState: 'loading' | 'ready' | 'error';
  storageError: string;
  reloadReports: () => Promise<void>;
  toastMessage: string;
  notify: (msg: string) => void;
};
const AppContext = createContext<AppContextType | undefined>(undefined);
export function AppProvider({ children }: { children: ReactNode }) {
  const { data: databaseExamples, isLoading: examplesLoading, isError: examplesError, refetch: reloadExamples } = useListSafetyReports({
    query: { queryKey: getListSafetyReportsQueryKey(), staleTime: 60_000, retry: 2 },
  });
  const [isAuthenticated, setIsAuthenticated] = useState(() => localStorage.getItem('sjsu_prototype_auth') === 'true');
  const [saved, setSaved] = useState<ReportRecord[]>([]);
  const [record, setRecord] = useState<ReportRecord>(initialRecord);
  const [draftRecord, setDraftRecord] = useState<ReportRecord>(initialRecord);
  const [editing, setEditing] = useState(false);
  const [storageState, setStorageState] = useState<'loading' | 'ready' | 'error'>('loading');
  const [storageError, setStorageError] = useState('');
  const [toastMessage, setToastMessage] = useState('');
  const examples = databaseExamples?.map((item): ReportRecord => ({
    ...item,
    locationAddress: item.locationAddress ?? undefined,
    reporterType: item.reporterType as ReportRecord['reporterType'],
    privacyMode: item.privacyMode as ReportRecord['privacyMode'],
    locationSource: item.locationSource as ReportRecord['locationSource'],
    incidentType: item.incidentType as ReportRecord['incidentType'],
    moderationStatus: item.moderationStatus as ReportRecord['moderationStatus'],
    priorityStatus: item.priorityStatus as ReportRecord['priorityStatus'],
  })) ?? [];
  const reports = [...saved, ...examples];
  const reloadReports = async () => {
    setStorageState('loading');
    try {
      const items = await loadReports();
      setSaved(items.sort((a, b) => b.submittedAt.localeCompare(a.submittedAt)));
      let selected: string | null = null;
      try { selected = sessionStorage.getItem('sjsu_selected_report'); } catch { /* Selection memory is optional. */ }
      const found = items.find(item => item.id === selected) ?? examples.find(item => item.id === selected) ?? items[0] ?? examples[0];
      if (found) { setRecord(found); setDraftRecord(found); }
      setStorageState('ready');
      setStorageError('');
    } catch (error) {
      setStorageError(error instanceof Error ? error.message : 'Local storage unavailable.');
      setStorageState('error');
    }
  };
  useEffect(() => { void reloadReports(); }, []);
  useEffect(() => {
    if (saved.length === 0 && examples.length > 0 && record.isDemo) {
      const selected = sessionStorage.getItem('sjsu_selected_report');
      const found = examples.find(item => item.id === selected) ?? examples[0];
      setRecord(found);
      setDraftRecord(found);
    }
  }, [examples.length]);
  const selectRecord = (id: string) => {
    const found = reports.find(item => item.id === id);
    if (found) {
      setRecord(found); setDraftRecord(found); setEditing(false);
      try { sessionStorage.setItem('sjsu_selected_report', id); } catch { /* Selection memory is optional. */ }
    }
  };
  const persistRecord = async (value: ReportRecord) => {
    if (value.isDemo) throw new Error('Demo examples cannot be changed. Select a saved submission instead.');
    await saveReport(value);
    setSaved(previous => [value, ...previous.filter(item => item.id !== value.id)]);
    setRecord(value); setDraftRecord(value);
    try { sessionStorage.setItem('sjsu_selected_report', value.id); } catch { /* The IndexedDB write already committed. */ }
  };
  const login = (email: string, pass: string) => {
    if (email === 'student@sjsu.edu' && pass === 'demo123') {
      localStorage.setItem('sjsu_prototype_auth', 'true');
      setIsAuthenticated(true);
      return true;
    }
    return false;
  };
  const logout = () => { localStorage.removeItem('sjsu_prototype_auth'); setIsAuthenticated(false); };
  const notify = (message: string) => {
    setToastMessage(message);
    window.setTimeout(() => setToastMessage(''), 4000);
  };
  return <AppContext.Provider value={{
    isAuthenticated, login, logout, record, setRecord, draftRecord, setDraftRecord,
    editing, setEditing, reports, selectRecord, persistRecord,
    storageState: examplesLoading ? 'loading' : storageState,
    storageError: examplesError ? 'Database examples could not be loaded.' : storageError,
    reloadReports: async () => { await Promise.all([reloadReports(), reloadExamples()]); },
    toastMessage, notify,
  }}>{children}</AppContext.Provider>;
}
export function useAppContext() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useAppContext must be used within an AppProvider');
  return context;
}