export const CATEGORIES = [
  'Fraud', 'Forgery', 'Forgery — Bad Checks', 'Fraudulent Use of Credit/Debit Card',
  'Harassing Communications', 'Identity Theft', 'Lost Property', 'Non-Injury Traffic Accident',
  'Theft', 'Theft from Vehicle', 'Vandalism', 'Vandalism of Vehicle', 'Other Safety Concern',
] as const;
export type Category = typeof CATEGORIES[number];
export type Coordinates = { latitude: number; longitude: number };
export type ModerationStatus = 'Pending review' | 'Accepted' | 'Suspected spam';
export type PriorityStatus = 'Critical' | 'High' | 'Normal' | 'Low' | 'Unknown';
export interface ReportRecord {
  id: string;
  isDemo: boolean;
  reporterType: 'student' | 'resident';
  privacyMode: 'anonymous' | 'identified';
  displayName?: string;
  image?: string;
  coordinates: Coordinates;
  locationSource: 'exif' | 'manual' | 'address';
  locationAddress?: string;
  locationConfirmed: boolean;
  location: string;
  incidentDate: string;
  incidentTime: string;
  description: string;
  incidentType: Category;
  moderationStatus: ModerationStatus;
  priorityStatus: PriorityStatus;
  moderationReason: string;
  submittedAt: string;
}

const sample = (n: number, location: string, latitude: number, longitude: number, incidentType: Category, incidentDate: string, incidentTime: string, description: string): ReportRecord => ({
  id: `DEMO-${String(n).padStart(3, '0')}`, isDemo: true, reporterType: n % 2 ? 'student' : 'resident',
  privacyMode: 'anonymous', coordinates: { latitude, longitude }, locationSource: 'manual',
  locationConfirmed: true, location, incidentDate, incidentTime, description, incidentType,
  moderationStatus: 'Pending review', priorityStatus: 'Normal', moderationReason: 'Fictional demonstration record; not reviewed.',
  submittedAt: `${incidentDate}T${incidentTime}:00`,
});

export const SAMPLE_REPORTS: ReportRecord[] = [
  sample(1, 'Student Union', 37.3365, -121.8806, 'Lost Property', '2025-03-12', '14:20', 'Fictional example: a backpack was reported missing after a study session.'),
  sample(2, 'MLK Library', 37.3355, -121.8840, 'Harassing Communications', '2025-03-14', '18:45', 'Fictional example: repeated unwanted messages were reported near the library.'),
  sample(3, 'Paseo de San Antonio', 37.3339, -121.8907, 'Theft', '2025-03-16', '12:10', 'Fictional example: a bicycle was reported missing from a public rack.'),
  sample(4, 'San Pedro Square', 37.3367, -121.8937, 'Fraud', '2025-03-17', '20:30', 'Fictional example: a visitor described a suspicious payment request.'),
  sample(5, 'South First Street', 37.3305, -121.8864, 'Vandalism', '2025-03-19', '09:15', 'Fictional example: damage to a public-facing fixture was noticed.'),
  sample(6, 'Washington Square', 37.3330, -121.8835, 'Other Safety Concern', '2025-03-20', '16:05', 'Fictional example: a pathway light was reported out.'),
  sample(7, 'Campus Village', 37.3310, -121.8769, 'Theft from Vehicle', '2025-03-21', '22:40', 'Fictional example: an item was reported missing from a parked vehicle.'),
  sample(8, 'Downtown transit area', 37.3363, -121.8882, 'Lost Property', '2025-03-23', '07:50', 'Fictional example: a wallet was reported missing after a transit trip.'),
  sample(9, 'SJSU east campus walkway', 37.3350, -121.8786, 'Vandalism of Vehicle', '2025-03-24', '11:25', 'Fictional example: damage to a parked vehicle was described.'),
  sample(10, 'Paseo de San Carlos', 37.3326, -121.8803, 'Identity Theft', '2025-03-25', '15:35', 'Fictional example: a student reported a suspicious account notification.'),
];