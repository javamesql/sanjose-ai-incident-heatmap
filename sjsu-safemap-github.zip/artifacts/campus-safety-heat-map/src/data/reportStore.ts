import type { ReportRecord } from './reports';

const DB_NAME = 'sjsu-safemap-reports';
const STORE = 'reports';
function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains(STORE)) request.result.createObjectStore(STORE, { keyPath: 'id' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error('Local report storage could not be opened.'));
  });
}
export async function loadReports(): Promise<ReportRecord[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const request = tx.objectStore(STORE).getAll();
    request.onsuccess = () => resolve(request.result as ReportRecord[]);
    request.onerror = () => reject(request.error ?? new Error('Could not read saved reports.'));
    tx.oncomplete = () => db.close();
  });
}
export async function saveReport(record: ReportRecord): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).put(record);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); reject(tx.error ?? new Error('Could not save report.')); };
    tx.onabort = () => { db.close(); reject(tx.error ?? new Error('Report storage transaction was cancelled.')); };
  });
}