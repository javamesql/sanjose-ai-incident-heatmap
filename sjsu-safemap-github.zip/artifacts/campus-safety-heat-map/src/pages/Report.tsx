import React, { useState, useRef } from 'react';
import { useLocation } from 'wouter';
import { ArrowRight, Info, ShieldCheck, Image as ImageIcon, X, AlertTriangle, Layers3, FileText, MapPin, UserRound, HelpCircle, Crosshair, CheckCircle2 } from 'lucide-react';
import { useAppContext, type ReportRecord, type ModerationStatus, type PriorityStatus } from '../context/AppContext';
import { LocationPicker, Coordinates } from '../components/LocationPicker';
import { CATEGORIES, type Category } from '../data/reports';
import exifr from 'exifr';

function HelpTip({ text }: { text: string }) {
  return (
    <span className="help-tip">
      <button
        type="button"
        className="help-tip-trigger"
        aria-label={`Help: ${text}`}
      >
        <HelpCircle size={14} />
      </button>
      <span className="help-tip-content" role="tooltip">{text}</span>
    </span>
  );
}

export default function Report() {
  const [, setLocation] = useLocation();
  const { persistRecord, setEditing, notify, isAuthenticated, storageState, storageError, reloadReports } = useAppContext();

  // Local Form State
  const [reporterType, setReporterType] = useState<'student' | 'resident'>(isAuthenticated ? 'student' : 'resident');
  const [reportText, setReportText] = useState('');
  const [locationName, setLocationName] = useState('');
  const [incidentDate, setIncidentDate] = useState('');
  const [incidentTime, setIncidentTime] = useState('');
  const [category, setCategory] = useState<Category | ''>('');
  const [reviewing, setReviewing] = useState(false);
  const [saving, setSaving] = useState(false);
  const savingRef = useRef(false);
  const [saveError, setSaveError] = useState('');
  const [privacyMode, setPrivacyMode] = useState<'anonymous' | 'identified'>('anonymous');
  const [displayName, setDisplayName] = useState('');
  const [image, setImage] = useState<string | null>(null);
  
  // Location
  const [coordinates, setCoordinates] = useState<Coordinates | undefined>(undefined);
  const [locationSource, setLocationSource] = useState<'exif' | 'manual' | 'address' | undefined>(undefined);
  const [locationAddress, setLocationAddress] = useState<string | undefined>();
  const [locationConfirmed, setLocationConfirmed] = useState(false);
  const [showLocationPicker, setShowLocationPicker] = useState(false);
  const [exifSearchStatus, setExifSearchStatus] = useState<'searching' | 'found' | 'not_found' | 'idle'>('idle');

  const [errors, setErrors] = useState<{ reportText?: string; image?: string; location?: string; locationName?: string; date?: string; category?: string }>({});
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      setErrors(prev => ({ ...prev, image: 'Please upload a valid image file (JPG, PNG, or WEBP).' }));
      e.target.value = '';
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setErrors(prev => ({ ...prev, image: 'Image size should be less than 5MB.' }));
      e.target.value = '';
      return;
    }

    setExifSearchStatus('searching');

    const reader = new FileReader();
    reader.onload = (event) => {
      setImage(event.target?.result as string);
      setErrors(prev => ({ ...prev, image: undefined }));
    };
    reader.readAsDataURL(file);

    try {
      const exifData = await exifr.parse(file, true);
      if (exifData?.latitude && exifData?.longitude) {
        setCoordinates({ latitude: exifData.latitude, longitude: exifData.longitude });
        setLocationSource('exif');
        setLocationConfirmed(false); // require explicit confirmation
        setExifSearchStatus('found');
      } else {
        setExifSearchStatus('not_found');
      }
    } catch (err) {
      setExifSearchStatus('not_found');
    }
  };

  const removeImage = () => {
    setImage(null);
    if (locationSource === 'exif') {
      setCoordinates(undefined);
      setLocationSource(undefined);
      setLocationAddress(undefined);
      setLocationConfirmed(false);
    }
    setExifSearchStatus('idle');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const validateForm = () => {
    const newErrors: typeof errors = {};
    let valid = true;

    if (!reportText.trim() || reportText.length < 10) {
      newErrors.reportText = 'Please provide more details about what you observed (min 10 chars).';
      valid = false;
    }
    
    if (!locationConfirmed || !coordinates || showLocationPicker) {
      newErrors.location = 'Please confirm the incident location on the map.';
      valid = false;
    }
    if (!locationName.trim()) { newErrors.locationName = 'Enter a landmark or location name.'; valid = false; }
    if (!incidentDate || !incidentTime || Number.isNaN(new Date(`${incidentDate}T${incidentTime}`).getTime())) {
      newErrors.date = 'Enter an incident date and time.'; valid = false;
    } else if (new Date(`${incidentDate}T${incidentTime}`).getTime() > Date.now()) {
      newErrors.date = 'Incident time cannot be in the future.'; valid = false;
    }
    if (!category) { newErrors.category = 'Choose a category yourself before continuing.'; valid = false; }

    setErrors(newErrors);
    return valid;
  };

  const determineModeration = (text: string): { status: ModerationStatus, priority: PriorityStatus, reason: string } => {
    const lowerText = text.toLowerCase();
    const words = lowerText.match(/[a-z0-9']+/g) ?? [];
    const uniqueWordRatio = words.length ? new Set(words).size / words.length : 0;
    const hasTimeReference = /\b(\d{1,2}(:\d{2})?\s*(am|pm)?|today|tonight|yesterday|morning|afternoon|evening|monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b/.test(lowerText);
    
    // Spam checks
    if (
      lowerText.length < 10 ||
      /^(test|asdf|buy now|click here)\b/.test(lowerText) ||
      /\b(buy now|click here|limited offer|promo code|free money)\b/.test(lowerText) ||
      (words.length >= 6 && uniqueWordRatio < 0.35)
    ) {
      return { 
        status: isAuthenticated ? 'Pending review' : 'Suspected spam', 
        priority: 'Unknown', 
        reason: 'Possible promotional, repeated, or nonsensical content; retained for human review.' 
      };
    }

    // Low priority / minor maintenance
    if (
      /\b(grass|light bulb|graffiti|litter|parking is bad|too loud|annoying|general opinion|suggestion|maintenance)\b/.test(lowerText) ||
      !hasTimeReference
    ) {
      return { 
        status: isAuthenticated ? 'Pending review' : 'Accepted', 
        priority: 'Low', 
        reason: hasTimeReference
          ? 'Possible minor maintenance issue or general concern; retained for human review.'
          : 'No specific time was detected in the description; retained for human review.' 
      };
    }

    // High/Critical priority
    if (lowerText.match(/(gun|fire|urgent|danger|weapon|assault|hurt)/)) {
      return { status: 'Pending review', priority: 'High', reason: 'Flagged for urgent manual review based on keywords.' };
    }

    return { status: 'Pending review', priority: 'Normal', reason: 'Standard initial assignment.' };
  };

  const submitReport = async () => {
    if (savingRef.current || !validateForm() || !coordinates || !category) { setReviewing(false); return; }
    savingRef.current = true;
    setSaving(true);
    setSaveError('');

    const modResult = determineModeration(reportText);

    const newRecord: ReportRecord = {
      id: `SJSU-${crypto.randomUUID()}`,
      isDemo: false,
      reporterType,
      description: reportText,
      privacyMode,
      displayName: privacyMode === 'identified' && displayName.trim() ? displayName.trim() : undefined,
      image: image || undefined,
      coordinates,
      locationSource: locationSource || 'manual',
      locationAddress: locationSource === 'address' ? locationAddress : undefined,
      locationConfirmed: true,
      location: locationName.trim(),
      incidentDate,
      incidentTime,
      incidentType: category,
      moderationStatus: modResult.status,
      priorityStatus: modResult.priority,
      moderationReason: modResult.reason,
      submittedAt: new Date().toISOString()
    };

    try {
      await persistRecord(newRecord);
      setEditing(false);
      notify(`Report ${newRecord.id} saved locally.`);
      setLocation('/map');
    } catch (error) {
      setSaveError(`${error instanceof Error ? error.message : 'Local storage failed.'} Check browser storage permissions or free space, then try again. Your form is still here.`);
    } finally {
      savingRef.current = false;
      setSaving(false);
    }
  };
  const previewPoint = coordinates && (
    coordinates.latitude >= 37.3312 && coordinates.latitude <= 37.3382 &&
    coordinates.longitude >= -121.8848 && coordinates.longitude <= -121.8768
      ? {
          area: 'CAMPUS AREA',
          left: ((coordinates.longitude + 121.8848) / .008) * 100,
          top: ((37.3382 - coordinates.latitude) / .007) * 100,
        }
      : coordinates.latitude >= 37.327 && coordinates.latitude <= 37.340 &&
        coordinates.longitude >= -121.898 && coordinates.longitude <= -121.874
        ? {
            area: 'DOWNTOWN / CAMPUS OVERVIEW',
            left: ((coordinates.longitude + 121.898) / .024) * 100,
            top: ((37.340 - coordinates.latitude) / .013) * 100,
          }
        : undefined
  );

  return (
    <div className="page-wrap">
      <section className="page-intro">
        <div className="eyebrow"><span className="eyebrow-line" /> Report a campus safety signal</div>
        <h1 className="display-title">Put the details somewhere useful.</h1>
        <p className="intro-copy">
          Share what you noticed in your own words. Review every field before saving it locally.
          Built-in fictional examples are always labeled separately from saved submissions.
        </p>
      </section>

      <div className="entry-grid">
        <section className="surface report-card" aria-labelledby="report-heading">
          <div className="card-header">
            <div>
              <h2 id="report-heading" className="card-title">{reviewing ? 'Review before submitting' : 'Incident Details'}</h2>
              <p className="card-caption">{reviewing ? 'Nothing is saved until you confirm below.' : 'The more specific the place and time, the more useful the record.'}</p>
            </div>
            <div className="step-label">{reviewing ? '02 / 02' : '01 / 02'}</div>
          </div>
          {reviewing ? (
            <div className="submission-review">
              <p className="notice"><Info size={15} /> Saved reports stay in this browser only. This is not an emergency service.</p>
              <dl className="review-details">
                <div><dt>Location / landmark</dt><dd>{locationName}</dd></div>
                <div><dt>Confirmed marker</dt><dd><span className="review-marker" aria-hidden="true"><MapPin size={18} /></span>{coordinates?.latitude.toFixed(5)}, {coordinates?.longitude.toFixed(5)} ({locationSource === 'address' ? 'Address search' : locationSource === 'exif' ? 'Photo GPS' : 'Manual selection'})</dd></div>
                {locationAddress && <div><dt>Selected address</dt><dd>{locationAddress}</dd></div>}
                <div><dt>Incident date and time</dt><dd>{incidentDate} at {incidentTime}</dd></div>
                <div><dt>Category</dt><dd>{category}</dd></div>
                <div><dt>Description</dt><dd style={{ whiteSpace: 'pre-wrap' }}>{reportText}</dd></div>
                <div><dt>Reporter</dt><dd>{reporterType === 'student' ? 'Student / staff' : 'Resident / visitor'}</dd></div>
                <div><dt>Anonymous</dt><dd>{privacyMode === 'anonymous' ? 'Yes — no identity is stored' : `No${displayName.trim() ? ` — ${displayName.trim()}` : ' — no display name provided'}`}</dd></div>
              </dl>
              {coordinates && previewPoint && <div className="review-location-map" role="img" aria-label={`Review marker at ${coordinates.latitude.toFixed(5)}, ${coordinates.longitude.toFixed(5)} on illustrative ${previewPoint.area.toLowerCase()}`}>
                <span className="review-map-title">CONFIRMED LOCATION · ILLUSTRATIVE {previewPoint.area}</span>
                <span className="review-map-pin" style={{
                  left: `${previewPoint.left}%`,
                  top: `${previewPoint.top}%`,
                }}><MapPin size={23} /></span>
              </div>}
              {coordinates && !previewPoint && <p className="save-error" role="status">This confirmed location is outside the illustrated map area. Its exact coordinates above will be saved; no map position is estimated.</p>}
              {image && <div className="image-preview"><strong>Attached image</strong><img src={image} alt="Image to be saved with this report" /></div>}
              {saveError && <div role="alert" className="save-error">{saveError}</div>}
              {storageState === 'loading' && <div role="status" className="save-error">Checking local report storage…</div>}
              {storageState === 'error' && <div role="alert" className="save-error">Local storage is unavailable: {storageError} <button type="button" className="secondary-button" onClick={() => void reloadReports()}>Retry storage</button></div>}
              <div className="form-foot">
                <button type="button" className="secondary-button" disabled={saving} onClick={() => { setReviewing(false); setSaveError(''); }}>Back to edit details</button>
                <button type="button" className="primary-button" disabled={saving || storageState !== 'ready'} onClick={() => void submitReport()} data-testid="button-submit-report">{saving ? 'Saving locally…' : 'Confirm and save report'} <ArrowRight size={15} /></button>
              </div>
            </div>
          ) : <>
          <div style={{ marginBottom: '24px' }}>
             <label className="field-label">
                <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  Reporter Profile
                  <HelpTip text="Indicate your relationship to SJSU." />
                </span>
             </label>
             <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
               <label style={{ display: 'flex', gap: '8px', alignItems: 'center', cursor: 'pointer', padding: '12px', border: `1px solid ${reporterType === 'student' ? 'hsl(var(--primary))' : 'hsl(var(--border))'}`, borderRadius: '8px', background: reporterType === 'student' ? 'hsl(var(--primary)/0.05)' : 'transparent' }}>
                 <input type="radio" name="reporterType" value="student" checked={reporterType === 'student'} onChange={() => setReporterType('student')} />
                 <div style={{ fontSize: '13px', fontWeight: 600 }}>SJSU Student / Staff</div>
               </label>
               <label style={{ display: 'flex', gap: '8px', alignItems: 'center', cursor: 'pointer', padding: '12px', border: `1px solid ${reporterType === 'resident' ? 'hsl(var(--primary))' : 'hsl(var(--border))'}`, borderRadius: '8px', background: reporterType === 'resident' ? 'hsl(var(--primary)/0.05)' : 'transparent' }}>
                 <input type="radio" name="reporterType" value="resident" checked={reporterType === 'resident'} onChange={() => setReporterType('resident')} />
                 <div style={{ fontSize: '13px', fontWeight: 600 }}>Resident / Visitor</div>
               </label>
             </div>
          </div>

          <div style={{ marginBottom: '24px' }}>
            <label className="field-label" htmlFor="incident-report">
              <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                What happened?
                <HelpTip text="Describe what happened, including the approximate time, location, and observable details." />
              </span>
              <span className="field-hint">YOUR DESCRIPTION</span>
            </label>
            <textarea
              id="incident-report"
              className="report-input"
              value={reportText}
              onChange={(e) => { setReportText(e.target.value); setErrors(prev => ({...prev, reportText: undefined})) }}
              placeholder="For example: On Thursday around 8:40 PM, I noticed..."
              data-testid="input-incident-report"
            />
            {errors.reportText && <div style={{ color: 'hsl(var(--destructive))', fontSize: '12px', marginTop: '6px', display: 'flex', alignItems: 'center', gap: '4px' }}><AlertTriangle size={14} /> {errors.reportText}</div>}
          </div>
          <div className="report-field-grid">
            <div>
              <label className="field-label" htmlFor="incident-date">Incident date</label>
              <input id="incident-date" className="detail-input" type="date" value={incidentDate} max={new Date().toISOString().slice(0, 10)} onChange={e => { setIncidentDate(e.target.value); setErrors(prev => ({ ...prev, date: undefined })); }} />
            </div>
            <div>
              <label className="field-label" htmlFor="incident-time">Incident time</label>
              <input id="incident-time" className="detail-input" type="time" value={incidentTime} onChange={e => { setIncidentTime(e.target.value); setErrors(prev => ({ ...prev, date: undefined })); }} />
            </div>
          </div>
          {errors.date && <p role="alert" className="save-error">{errors.date}</p>}
          <div style={{ marginBottom: '24px' }}>
            <label className="field-label" htmlFor="incident-category">Category <span className="field-hint">YOUR FINAL CHOICE</span></label>
            <select id="incident-category" className="detail-input" value={category} onChange={e => { setCategory(e.target.value as Category); setErrors(prev => ({ ...prev, category: undefined })); }}>
              <option value="">Choose a category</option>
              {CATEGORIES.map(item => <option value={item} key={item}>{item}</option>)}
            </select>
            <p className="card-caption">You can change this selection at any time before saving.</p>
            {errors.category && <p role="alert" className="save-error">{errors.category}</p>}
          </div>

          <div style={{ marginBottom: '24px' }}>
            <label className="field-label">
              <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                Photo Evidence
                <HelpTip text="Optionally attach one JPG, PNG, or WEBP image under 5MB that relates to the incident." />
              </span>
            </label>
            {!image ? (
              <div style={{ border: '1px dashed hsl(var(--border))', borderRadius: '8px', padding: '24px', textAlign: 'center', background: 'hsl(var(--muted)/0.3)' }}>
                <ImageIcon size={24} style={{ margin: '0 auto 12px', color: 'hsl(var(--muted-foreground))' }} />
                 <div style={{ fontSize: '13px', marginBottom: '12px', color: 'hsl(var(--foreground))' }}>Upload an image (JPG, PNG, WEBP)</div>
                <button type="button" className="secondary-button" onClick={() => fileInputRef.current?.click()} style={{ fontSize: '12px', height: '32px' }}>Choose File</button>
                <input type="file" accept="image/jpeg, image/png, image/webp" ref={fileInputRef} onChange={handleImageUpload} style={{ display: 'none' }} />
              </div>
            ) : (
              <div className="image-preview">
                <img src={image} alt="Incident preview" />
                <button type="button" className="image-remove-button" onClick={removeImage} aria-label="Remove uploaded image" data-testid="button-remove-image">
                  <X size={14} /> Remove image
                </button>
              </div>
            )}
            {errors.image && <div style={{ color: 'hsl(var(--destructive))', fontSize: '12px', marginTop: '6px', display: 'flex', alignItems: 'center', gap: '4px' }}><AlertTriangle size={14} /> {errors.image}</div>}
          </div>

          <div style={{ marginBottom: '24px' }}>
             <label className="field-label">
              <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                Incident Location
                <HelpTip text="Explicitly confirm the map coordinates for this report." />
              </span>
            </label>
             <label className="field-label" htmlFor="location-name">Location or landmark name</label>
              <input id="location-name" className="detail-input" value={locationName} onChange={e => { setLocationName(e.target.value); setErrors(prev => ({ ...prev, locationName: undefined })); }} placeholder="e.g. Student Union, north entrance" />
             {errors.locationName && <p role="alert" className="save-error">{errors.locationName}</p>}

            {exifSearchStatus === 'found' && !locationConfirmed && !showLocationPicker && (
               <div style={{ padding: '12px', background: 'hsl(var(--primary)/0.08)', borderRadius: '8px', marginBottom: '12px', display: 'flex', gap: '10px', alignItems: 'flex-start' }}>
                 <Crosshair size={16} style={{ color: 'hsl(var(--primary))', marginTop: '2px' }} />
                 <div>
                   <div style={{ fontSize: '13px', fontWeight: 600, color: 'hsl(var(--primary))' }}>Location detected from photo</div>
                     {coordinates && (
                       <div style={{ fontFamily: 'Space Mono, monospace', fontSize: '11px', marginTop: '4px' }}>
                         {coordinates.latitude.toFixed(5)}, {coordinates.longitude.toFixed(5)}
                       </div>
                     )}
                   <div style={{ fontSize: '12px', color: 'hsl(var(--muted-foreground))', marginTop: '4px' }}>Please review and confirm these coordinates on the map.</div>
                   <button type="button" className="primary-button" onClick={() => setShowLocationPicker(true)} style={{ height: '28px', fontSize: '11px', marginTop: '10px' }}>Review Location</button>
                 </div>
               </div>
            )}

            {exifSearchStatus === 'not_found' && !showLocationPicker && !locationConfirmed && (
               <div style={{ padding: '12px', background: 'hsl(var(--muted)/0.5)', borderRadius: '8px', marginBottom: '12px', fontSize: '12px', color: 'hsl(var(--muted-foreground))' }}>
                 Location could not be automatically detected. Please select the incident location manually.
               </div>
            )}

            {showLocationPicker ? (
               <div style={{ marginTop: '12px' }}>
                 <LocationPicker 
                   initialCoordinates={coordinates}
                    initialSource={locationSource}
                    initialAddress={locationAddress}
                    onConfirm={(coords, source, address) => {
                     setCoordinates(coords);
                      setLocationSource(source);
                      setLocationAddress(source === 'address' ? address : undefined);
                     setLocationConfirmed(true);
                     setShowLocationPicker(false);
                     setErrors(prev => ({...prev, location: undefined}));
                   }}
                   onCancel={() => setShowLocationPicker(false)}
                 />
               </div>
            ) : locationConfirmed ? (
               <div style={{ padding: '12px', border: '1px solid hsl(158 42% 40%)', background: 'hsl(158 42% 40% / 0.05)', borderRadius: '8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                 <div style={{ display: 'flex', gap: '8px', alignItems: 'center', color: 'hsl(158 42% 28%)' }}>
                   <CheckCircle2 size={16} />
                    <div>
                      <div style={{ fontSize: '13px', fontWeight: 600 }}>Location Confirmed</div>
                      {coordinates && (
                        <div style={{ fontFamily: 'Space Mono, monospace', fontSize: '11px', marginTop: '2px' }}>
                          {coordinates.latitude.toFixed(5)}, {coordinates.longitude.toFixed(5)}
                        </div>
                      )}
                      {locationAddress && <div style={{ fontSize: '11px', marginTop: '4px' }}>{locationAddress}</div>}
                    </div>
                 </div>
                 <button type="button" className="text-button" onClick={() => setShowLocationPicker(true)}>Edit</button>
               </div>
            ) : exifSearchStatus !== 'found' && (
               <button type="button" className="secondary-button" onClick={() => setShowLocationPicker(true)} style={{ width: '100%' }}>
                 <MapPin size={14} /> Choose Map Location
               </button>
            )}

            {errors.location && <div style={{ color: 'hsl(var(--destructive))', fontSize: '12px', marginTop: '6px', display: 'flex', alignItems: 'center', gap: '4px' }}><AlertTriangle size={14} /> {errors.location}</div>}
          </div>

          <div style={{ marginBottom: '24px' }}>
            <label className="field-label">
              <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                Privacy Options
                <HelpTip text="Choose whether to remain anonymous or provide a display name." />
              </span>
            </label>
            <div style={{ display: 'grid', gap: '12px' }}>
              <label style={{ display: 'flex', gap: '12px', alignItems: 'flex-start', cursor: 'pointer', padding: '12px', border: `1px solid ${privacyMode === 'anonymous' ? 'hsl(var(--primary))' : 'hsl(var(--border))'}`, borderRadius: '8px', background: privacyMode === 'anonymous' ? 'hsl(var(--primary)/0.05)' : 'transparent' }}>
                <input type="radio" name="privacy" value="anonymous" checked={privacyMode === 'anonymous'} onChange={() => setPrivacyMode('anonymous')} style={{ marginTop: '2px' }} />
                <div>
                  <div style={{ fontSize: '13px', fontWeight: 600 }}>Submit anonymously</div>
                  <div style={{ fontSize: '12px', color: 'hsl(var(--muted-foreground))', marginTop: '4px' }}>No public name or contact information will be shown to reviewers.</div>
                </div>
              </label>
              
              <label style={{ display: 'flex', gap: '12px', alignItems: 'flex-start', cursor: 'pointer', padding: '12px', border: `1px solid ${privacyMode === 'identified' ? 'hsl(var(--primary))' : 'hsl(var(--border))'}`, borderRadius: '8px', background: privacyMode === 'identified' ? 'hsl(var(--primary)/0.05)' : 'transparent' }}>
                <input type="radio" name="privacy" value="identified" checked={privacyMode === 'identified'} onChange={() => setPrivacyMode('identified')} style={{ marginTop: '2px' }} />
                <div>
                  <div style={{ fontSize: '13px', fontWeight: 600 }}>Provide a display name</div>
                  <div style={{ fontSize: '12px', color: 'hsl(var(--muted-foreground))', marginTop: '4px' }}>Reviewers will see this name. Private identifiers are never collected.</div>
                </div>
              </label>
            </div>
          </div>

          {privacyMode === 'identified' && (
            <div style={{ marginBottom: '24px', animation: 'appear .2s ease both' }}>
              <label className="field-label" htmlFor="display-name">
                <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  Display Name <span className="field-hint">OPTIONAL</span>
                  <HelpTip text="Enter the display name reviewers may see." />
                </span>
              </label>
              <input 
                id="display-name"
                type="text" 
                value={displayName}
                onChange={e => setDisplayName(e.target.value)}
                style={{ width: '100%', padding: '12px', borderRadius: '6px', border: '1px solid hsl(var(--input))', background: 'hsl(39 31% 95%)', fontSize: '14px' }}
                placeholder="How should we refer to you?"
              />
            </div>
          )}

          <div className="form-foot">
            <div className="privacy-note">
              <ShieldCheck size={14} />
              <span>Prototype only. Do not enter personal or emergency information.</span>
            </div>
            <button className="primary-button" type="button" onClick={() => { if (validateForm()) setReviewing(true); }} data-testid="button-review-report">
              Review report <ArrowRight size={15} />
            </button>
          </div>
          </>}
        </section>

        <div className="side-stack">
          <section className="surface info-card info-card-accent">
            <h2 className="info-card-title"><Layers3 size={15} /> What happens next</h2>
            <dl className="info-list">
              <div className="info-list-row">
                <div className="info-list-icon"><FileText size={16} /></div>
                <div><dt>Structured, not hidden</dt><dd>Key details are surfaced so a person can check them.</dd></div>
              </div>
              <div className="info-list-row">
                <div className="info-list-icon"><MapPin size={16} /></div>
                <div><dt>Location signal</dt><dd>A draft map shows where this report may belong.</dd></div>
              </div>
              <div className="info-list-row">
                <div className="info-list-icon"><UserRound size={16} /></div>
                <div><dt>Human decision</dt><dd>An analyst approves, rejects, or corrects the draft.</dd></div>
              </div>
            </dl>
          </section>
          <div className="notice">
            <Info size={15} />
            <span>This is not a live safety service. In an emergency, contact the appropriate campus or local emergency service.</span>
          </div>
        </div>
      </div>
    </div>
  );
}
