import React, { ReactNode, useState } from 'react';
import { useLocation } from 'wouter';
import { 
  AlertTriangle, ArrowLeft, BadgeCheck, Check, CircleDotDashed, Clock3, 
  Crosshair, Edit3, FileText, Info, MapPin, RotateCcw, Send, ShieldCheck, X, Image as ImageIcon,
  Activity, Search
} from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import type { ReportRecord, PriorityStatus } from '../data/reports';

function latLngToXY(lat: number, lng: number): { x: number; y: number } {
  const SJSU_BOUNDS = { north: 37.3382, south: 37.3312, west: -121.8848, east: -121.8768 };
  const x = ((lng - SJSU_BOUNDS.west) / (SJSU_BOUNDS.east - SJSU_BOUNDS.west)) * 760;
  const y = ((SJSU_BOUNDS.north - lat) / (SJSU_BOUNDS.north - SJSU_BOUNDS.south)) * 355;
  return { x, y };
}
function visibleLocation(item: ReportRecord, isAuthenticated: boolean): string {
  return !item.isDemo && !isAuthenticated && item.privacyMode === 'anonymous'
    ? 'Anonymous report'
    : item.location;
}

export default function Map() {
  const [, setLocation] = useLocation();
  const { 
    record, draftRecord, setDraftRecord,
    editing, setEditing, notify, isAuthenticated, reports, selectRecord, persistRecord, storageState, storageError, reloadReports
  } = useAppContext();
  const [actionError, setActionError] = useState('');
  const [busy, setBusy] = useState(false);
  const updateRecord = async (updated: ReportRecord, success: string) => {
    setBusy(true); setActionError('');
    try { await persistRecord(updated); notify(success); }
    catch (error) { setActionError(`${error instanceof Error ? error.message : 'Save failed.'} Changes were not saved. Check local browser storage and try again.`); }
    finally { setBusy(false); }
  };

  const handleStartOver = () => {
    setLocation('/report');
  };

  const handleEdit = () => {
    setDraftRecord(record);
    setEditing(true);
  };

  const handleSaveCorrection = async () => {
    setBusy(true); setActionError('');
    try {
      await persistRecord({ ...record, description: draftRecord.description, priorityStatus: draftRecord.priorityStatus, moderationStatus: 'Pending review' });
      setEditing(false);
      notify('Correction saved. Review status reset.');
    } catch (error) {
      setActionError(`${error instanceof Error ? error.message : 'Save failed.'} Your correction remains in the editor; check local storage and try again.`);
    } finally { setBusy(false); }
  };

  const statusIcon = record.moderationStatus === 'Accepted' ? <BadgeCheck size={15} /> : 
                     record.moderationStatus === 'Suspected spam' ? <RotateCcw size={14} /> : 
                     <CircleDotDashed size={15} />;
  
  const reporterLabel = record.privacyMode === 'anonymous' || !record.displayName 
    ? 'Anonymous ' + (record.reporterType === 'student' ? 'Student/Staff' : 'Resident')
    : record.displayName + ' (' + (record.reporterType === 'student' ? 'Student/Staff' : 'Resident') + ')';
  const hideAnonymousDetails = !isAuthenticated && !record.isDemo && record.privacyMode === 'anonymous';

  return (
    <div className="page-wrap">
      <section className="page-intro">
        <div className="eyebrow"><span className="eyebrow-line" /> {isAuthenticated ? 'Analyst review desk' : 'Submitted Report'}</div>
        <div className="review-intro">
          <div>
            <h1 className="display-title">{isAuthenticated ? 'A draft signal, ready for a second look.' : 'Reports in this browser.'}</h1>
            <p className="intro-copy">
              {isAuthenticated 
                ? 'Check saved submissions against their original details. Fictional examples are labeled and cannot be moderated.'
                : 'Saved submissions are local to this browser. Fictional examples are separate and never represent real incidents.'}
            </p>
          </div>
          <div className="review-status" data-testid="status-review">
            <div className="status-label">Moderation Status</div>
            <div className="status-value" style={{ color: record.moderationStatus === 'Suspected spam' ? 'hsl(var(--destructive))' : undefined }}>
              {statusIcon}{record.moderationStatus}
            </div>
          </div>
        </div>
      </section>
      {storageState === 'loading' && <div className="surface record-card" role="status">Loading saved and fictional reports…</div>}
      {storageState === 'error' && <div className="surface record-card save-error" role="alert">Reports could not be loaded: {storageError} <button type="button" className="secondary-button" onClick={() => void reloadReports()}>Retry</button></div>}
      <section className="surface record-list" aria-label="Saved and fictional reports">
        <div className="record-list-head"><strong>Incident records</strong><span>{reports.filter(item => !item.isDemo).length} saved locally · {reports.filter(item => item.isDemo).length} database examples</span></div>
        <div className="record-list-scroll">
          {reports.map(item => <button key={item.id} type="button" className={`record-list-item ${record.id === item.id ? 'selected' : ''}`} onClick={() => selectRecord(item.id)} aria-pressed={record.id === item.id} data-testid={`button-select-record-${item.id}`}>
            <span className="record-list-badge">{item.isDemo ? 'FICTIONAL DEMO' : 'SAVED LOCALLY'}</span>
            <strong>{visibleLocation(item, isAuthenticated)}</strong><small>{item.incidentType} · {item.incidentDate} {item.incidentTime}</small>
          </button>)}
        </div>
      </section>

      <div className="review-layout">
        <div className="review-column">
          <section className="surface record-card" aria-labelledby="record-heading">
            <div className="record-head">
              <div>
                <h2 id="record-heading" className="record-title">Extracted incident record</h2>
                 <div className="record-id">{record.isDemo ? 'FICTIONAL DEMO — NOT A REAL INCIDENT' : 'SAVED LOCALLY'} / {record.id} · Reported by: {reporterLabel}</div>
              </div>
              <div className="record-icon" aria-hidden="true"><FileText size={16} /></div>
            </div>
            
            {record.image && !editing && !hideAnonymousDetails && (
              <div style={{ marginTop: '16px', border: '1px solid hsl(var(--border))', borderRadius: '8px', overflow: 'hidden' }}>
                <div style={{ padding: '8px 12px', background: 'hsl(var(--muted)/0.5)', borderBottom: '1px solid hsl(var(--border))', fontSize: '11px', display: 'flex', alignItems: 'center', gap: '6px', color: 'hsl(var(--muted-foreground))' }}>
                  <ImageIcon size={12} /> Attached Photo Evidence
                </div>
                <img src={record.image} alt="Report evidence" style={{ width: '100%', maxHeight: '240px', objectFit: 'cover', display: 'block' }} />
              </div>
            )}

            {!editing ? (
              <>
                <div className="record-fields">
                   <RecordField icon={<MapPin size={12} />} label="Landmark / location" value={hideAnonymousDetails ? 'Hidden for anonymous reports in public view' : record.location} />
                   <RecordField icon={<Clock3 size={12} />} label="Incident date / time" value={`${record.incidentDate} · ${record.incidentTime}`} />
                   <RecordField icon={<Activity size={12} />} label="Category" value={record.incidentType} />
                   <RecordField icon={<ShieldCheck size={12} />} label="Anonymous" value={record.privacyMode === 'anonymous' ? 'Yes' : 'No'} />
                  <RecordField icon={<MapPin size={12} />} label="Coordinates" value={record.coordinates ? `${record.coordinates.latitude.toFixed(5)}, ${record.coordinates.longitude.toFixed(5)}` : 'Manual Location'} />
                  <RecordField icon={<Clock3 size={12} />} label="Submitted At" value={new Date(record.submittedAt).toLocaleString()} />
                  <RecordField
                    icon={<Activity size={12} />}
                    label="Source"
                    value={record.locationSource === 'exif' ? 'EXIF metadata (Confirmed)' : record.locationSource === 'address' ? 'Address search (Confirmed)' : 'Manual Selection'}
                  />
                   {record.locationAddress && !hideAnonymousDetails && <RecordField wide icon={<MapPin size={12} />} label="Selected address" value={record.locationAddress} />}
                  <div>
                    <div className="record-label">Priority</div>
                    <div className="record-value"><span className="urgency-pill"><span className="urgency-dot" />{record.priorityStatus}</span></div>
                  </div>
                  <RecordField wide icon={<Search size={12} />} label="Moderation Reason" value={record.moderationReason} description />
                   <RecordField wide icon={<FileText size={12} />} label="Description" value={hideAnonymousDetails ? 'Hidden for anonymous reports in public view. Full details are retained for the analyst.' : record.description} description />
                </div>
                 {isAuthenticated && !record.isDemo && (
                  <div className="review-actions">
                     <button className="primary-button action-approved" type="button" disabled={busy || storageState !== 'ready'} onClick={() => void updateRecord({...record, moderationStatus: 'Accepted'}, 'Record marked accepted.')} data-testid="button-approve-record">
                      <Check size={15} /> Accept
                    </button>
                     <button className="danger-button" type="button" disabled={busy || storageState !== 'ready'} onClick={() => void updateRecord({...record, moderationStatus: 'Suspected spam'}, 'Record marked as suspected spam.')} data-testid="button-reject-record">
                      <X size={15} /> Suspected Spam
                    </button>
                     <button className="secondary-button" type="button" disabled={busy || storageState !== 'ready'} onClick={handleEdit} data-testid="button-edit-record">
                      <Edit3 size={14} /> Edit or correct extracted fields
                    </button>
                  </div>
                )}
              </>
            ) : (
              <div className="correction-box">
                <div className="field-label">Correct the draft before deciding <span className="field-hint">ANALYST INPUT</span></div>
                <div className="edit-grid">
                  <label>Priority
                     <select value={draftRecord.priorityStatus} onChange={(event) => setDraftRecord({ ...draftRecord, priorityStatus: event.target.value as PriorityStatus })} data-testid="select-edit-priority">
                      <option>Unknown</option><option>Low</option><option>Normal</option><option>High</option><option>Critical</option>
                    </select>
                  </label>
                  <label>Description<textarea value={draftRecord.description} onChange={(event) => setDraftRecord({ ...draftRecord, description: event.target.value })} data-testid="input-edit-description" /></label>
                </div>
                <div className="edit-actions">
                  <button className="secondary-button" type="button" onClick={() => setEditing(false)} data-testid="button-cancel-edit">Cancel</button>
                   <button className="primary-button" type="button" disabled={busy} onClick={() => void handleSaveCorrection()} data-testid="button-save-correction"><Check size={14} /> Save correction</button>
                </div>
              </div>
            )}
          </section>
           {actionError && <div role="alert" className="save-error">{actionError}</div>}
          
          <div className="review-note">
            <ShieldCheck size={16} />
            <div><strong>Prototype Analyst Controls (Demo)</strong> {isAuthenticated ? 'Human review is the decision point. This draft is a signal for discussion.' : 'As an unauthenticated resident, you can view this review interface but cannot approve or reject.'}</div>
          </div>
        </div>

        <section className="surface map-card" aria-labelledby="map-heading">
          <div className="map-head">
            <div>
              <h2 id="map-heading" className="map-title">Draft location heat map</h2>
               <p className="map-caption">Static illustrative heat artwork; markers are selectable reports, not intensity or building identification.</p>
            </div>
             <div className="map-legend"><span className="legend-dot" /> Selectable incident markers</div>
          </div>
           <HeatMap reports={reports} selectedId={record.id} onSelect={selectRecord} isAuthenticated={isAuthenticated} />
           <div className="map-foot"><Info size={14} /> Campus artwork is illustrative and non-predictive. Downtown records outside its bounds appear in the overview below, never at the campus edge.</div>
        </section>
      </div>

      <div className="submitted-banner" style={{ marginTop: 18 }}>
         <span><Send size={14} /> {record.isDemo ? 'Fictional demonstration record — not a saved submission.' : `Saved locally · ${record.id}`}</span>
         <button className="text-button" type="button" onClick={handleStartOver} data-testid="button-new-report"><ArrowLeft size={12} /> Submit another report</button>
      </div>
    </div>
  );
}

function RecordField({ icon, label, value, wide, description }: { icon: ReactNode; label: string; value: string; wide?: boolean; description?: boolean; }) {
  return (
    <div className={wide ? 'record-field-wide' : undefined}>
      <div className="record-label">{icon}{label}</div>
      <div className={`record-value${description ? ' record-description' : ''}`}>{value}</div>
    </div>
  );
}

function HeatMap({ reports, selectedId, onSelect, isAuthenticated }: { reports: ReportRecord[]; selectedId: string; onSelect: (id: string) => void; isAuthenticated: boolean }) {
  const campus = reports.map(item => ({ item, pos: latLngToXY(item.coordinates.latitude, item.coordinates.longitude) }))
    .filter(({ pos }) => pos.x >= 0 && pos.x <= 760 && pos.y >= 0 && pos.y <= 355);
  const downtown = reports.filter(item => {
    const pos = latLngToXY(item.coordinates.latitude, item.coordinates.longitude);
    return pos.x < 0 || pos.x > 760 || pos.y < 0 || pos.y > 355;
  });
  const inOverview = (item: ReportRecord) =>
    item.coordinates.longitude >= -121.898 && item.coordinates.longitude <= -121.874 &&
    item.coordinates.latitude >= 37.327 && item.coordinates.latitude <= 37.340;

  return (
    <>
    <div className="map-visual" data-testid="visual-draft-heat-map">
      <div className="map-stamp"><Crosshair size={12} /> CAMPUS AREA / DRAFT</div>
      <svg viewBox="0 0 760 355" role="img" aria-label="Illustrative campus map with a draft signal">
        <defs>
          <pattern id="mapGrid" width="23" height="23" patternUnits="userSpaceOnUse">
            <path d="M 23 0 L 0 0 0 23" fill="none" stroke="#c0c9bb" strokeWidth="0.7" opacity=".6" />
          </pattern>
          <radialGradient id="heatA"><stop offset="0%" stopColor="#bd6255" stopOpacity=".56" /><stop offset="48%" stopColor="#d58b6f" stopOpacity=".23" /><stop offset="100%" stopColor="#d58b6f" stopOpacity="0" /></radialGradient>
          <radialGradient id="heatB"><stop offset="0%" stopColor="#c87b61" stopOpacity=".32" /><stop offset="100%" stopColor="#c87b61" stopOpacity="0" /></radialGradient>
        </defs>
        <rect width="760" height="355" fill="#d9ddcf" />
        <rect width="760" height="355" fill="url(#mapGrid)" />
        <path d="M-15 294 C130 245 165 255 267 275 S466 315 775 235" fill="none" stroke="#f4f0df" strokeWidth="28" opacity=".95" />
        <path d="M-15 294 C130 245 165 255 267 275 S466 315 775 235" fill="none" stroke="#aeb8aa" strokeWidth="1.1" />
        <path d="M140 -10 C155 71 143 142 173 212 S205 299 191 365" fill="none" stroke="#f4f0df" strokeWidth="19" />
        <path d="M140 -10 C155 71 143 142 173 212 S205 299 191 365" fill="none" stroke="#aeb8aa" strokeWidth="1" />
        <path d="M390 -10 C366 66 385 132 361 197 S335 301 348 365" fill="none" stroke="#f4f0df" strokeWidth="16" />
        <path d="M390 -10 C366 66 385 132 361 197 S335 301 348 365" fill="none" stroke="#aeb8aa" strokeWidth="1" />
        <path d="M543 -10 L552 370" stroke="#f4f0df" strokeWidth="22" /><path d="M543 -10 L552 370" stroke="#aeb8aa" strokeWidth="1" />
        <g fill="#b7c4b4" stroke="#8e9f96" strokeWidth="1">
          <path d="M65 54h104v67H65z" /><path d="M195 43h83v92h-83z" /><path d="M306 55h83v69h-83z" />
          <path d="M428 38h86v77h-86z" /><path d="M587 49h108v68H587z" /><path d="M65 158h91v58H65z" />
          <path d="M213 165h116v77H213z" /><path d="M396 157h90v65h-90z" /><path d="M583 155h105v94H583z" />
          <path d="M62 280h84v45H62z" /><path d="M226 285h105v43H226z" /><path d="M402 267h91v64h-91z" />
        </g>
        <g fill="#7f9e8c" opacity=".72">
          {/* Static random background points */}
          <circle cx="280" cy="153" r="13" /><circle cx="300" cy="145" r="9" /><circle cx="470" cy="267" r="17" /><circle cx="110" cy="246" r="14" /><circle cx="665" cy="285" r="13" />
        </g>
        
        {/* Static heat map layer as required */}
        <circle cx="480" cy="184" r="100" fill="url(#heatB)" />
        <circle cx="480" cy="184" r="61" fill="url(#heatA)" />
        <circle cx="480" cy="184" r="11" fill="#a8564b" opacity=".24" />
        
        {campus.map(({ item, pos }) => (
          <g key={item.id} tabIndex={0} role="button" aria-label={`Select ${item.isDemo ? 'fictional demo' : 'saved'} report ${item.id} at ${visibleLocation(item, isAuthenticated)}`} onClick={() => onSelect(item.id)} onKeyDown={event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); onSelect(item.id); } }} style={{ cursor: 'pointer' }}>
            <circle cx={pos.x} cy={pos.y} r={item.id === selectedId ? 15 : 12} fill={item.isDemo ? '#ba8b42' : '#256b63'} stroke="#f5f0e1" strokeWidth={item.id === selectedId ? 4 : 2} />
            <text x={pos.x} y={pos.y + 3} textAnchor="middle" fill="#f5f0e1" fontFamily="Space Mono, monospace" fontWeight="bold" fontSize="9">{item.isDemo ? 'D' : 'S'}</text>
          </g>
        ))}

        <g fill="#536962" fontFamily="Space Mono, monospace" fontSize="9"><text x="77" y="148">LIBRARY</text><text x="225" y="258">STUDENT UNION</text><text x="397" y="245">PASEO DE SAN CARLOS</text><text x="591" y="270">7TH STREET</text></g>
      </svg>
      <div className="map-scale">N <div className="map-scale-line" /></div>
      {campus.some(({ item }) => item.id === selectedId) && <div className="map-selection-label">{visibleLocation(reports.find(item => item.id === selectedId)!, isAuthenticated)} · {reports.find(item => item.id === selectedId)?.isDemo ? 'FICTIONAL DEMO' : 'SAVED LOCALLY'}</div>}
    </div>
    {downtown.length > 0 && <div className="downtown-overview">
      <strong>Downtown / outside campus artwork</strong>
      <p>Coordinate-based schematic overview; markers show report coordinates, not a specific building or heat intensity.</p>
      <div className="downtown-overview-map">
        <svg viewBox="0 0 500 160" role="img" aria-label="Schematic San José overview with selectable downtown and campus-edge report markers">
          <rect width="500" height="160" fill="#d9ddcf" />
          <path d="M0 50H500M0 105H500M130 0V160M285 0V160M420 0V160" stroke="#f4f0df" strokeWidth="10" />
          <text x="12" y="22" fill="#536962" fontFamily="Space Mono, monospace" fontSize="9">DOWNTOWN SAN JOSÉ / SCHEMATIC</text>
           {downtown.filter(inOverview).map(item => {
             const x = ((item.coordinates.longitude + 121.898) / .024) * 500;
             const y = ((37.340 - item.coordinates.latitude) / .013) * 160;
            return <g key={item.id} tabIndex={0} role="button" aria-label={`Select ${visibleLocation(item, isAuthenticated)}, ${item.isDemo ? 'fictional demo' : 'saved report'}`} onClick={() => onSelect(item.id)} onKeyDown={event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); onSelect(item.id); } }} style={{ cursor: 'pointer' }}>
              <circle cx={x} cy={y} r={item.id === selectedId ? 13 : 10} fill={item.isDemo ? '#ba8b42' : '#256b63'} stroke="#f5f0e1" strokeWidth={item.id === selectedId ? 4 : 2} />
              <text x={x} y={y + 3} textAnchor="middle" fill="#f5f0e1" fontFamily="Space Mono, monospace" fontSize="9">{item.isDemo ? 'D' : 'S'}</text>
            </g>;
          })}
        </svg>
      </div>
      <div className="downtown-points">
        {downtown.map(item => <button type="button" key={item.id} className={`downtown-point ${selectedId === item.id ? 'selected' : ''}`} onClick={() => onSelect(item.id)}>
           <span>{item.isDemo ? 'DEMO' : 'SAVED'}</span><strong>{visibleLocation(item, isAuthenticated)}</strong><small>{item.coordinates.latitude.toFixed(5)}, {item.coordinates.longitude.toFixed(5)}{!inOverview(item) ? ' · outside illustrated map area (no marker)' : ''}</small>
        </button>)}
      </div>
    </div>}
    </>
  );
}
