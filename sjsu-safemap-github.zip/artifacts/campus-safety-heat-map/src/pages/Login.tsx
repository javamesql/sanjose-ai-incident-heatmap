import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { Crosshair, ShieldCheck, ArrowRight, AlertTriangle, Users } from 'lucide-react';
import { useAppContext } from '../context/AppContext';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [, setLocation] = useLocation();
  const { login, isAuthenticated } = useAppContext();

  React.useEffect(() => {
    if (isAuthenticated) {
      setLocation('/report');
    }
  }, [isAuthenticated, setLocation]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!email || !password) {
      setError('Please enter both email and password.');
      return;
    }

    const success = login(email, password);
    if (success) {
      setLocation('/report');
    } else {
      setError('Invalid credentials. Please use the prototype demo login.');
    }
  };

  const handleResidentContinue = () => {
    setLocation('/report');
  };

  return (
    <div className="surface" style={{ padding: '40px', maxWidth: '440px', margin: '0 auto' }}>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', marginBottom: '32px' }}>
        <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: 'hsl(var(--primary))', color: 'white', display: 'grid', placeItems: 'center', marginBottom: '16px' }}>
          <Crosshair size={24} strokeWidth={2.3} />
        </div>
        <h1 style={{ margin: '0 0 8px', fontSize: '24px', fontWeight: 700 }}>SJSU SafeMap</h1>
        <p style={{ margin: 0, color: 'hsl(var(--muted-foreground))', fontSize: '14px', lineHeight: 1.5 }}>
          Student-built civic safety reporting prototype. Log in to access the testing environment.
        </p>
      </div>

      <div className="notice" style={{ marginBottom: '24px' }}>
        <ShieldCheck size={16} />
        <span>
          <strong>Prototype Only:</strong> Not a real emergency service. Do not submit actual personal information.
        </span>
      </div>

      <div style={{ marginBottom: '32px' }}>
        <button 
          className="secondary-button" 
          type="button" 
          onClick={handleResidentContinue} 
          style={{ width: '100%', height: '48px', fontSize: '14px', justifyContent: 'center' }}
        >
          <Users size={18} /> Continue as Resident / Visitor
        </button>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '24px' }}>
        <div style={{ flex: 1, height: '1px', background: 'hsl(var(--border))' }} />
        <div style={{ fontSize: '12px', fontWeight: 600, color: 'hsl(var(--muted-foreground))', textTransform: 'uppercase', letterSpacing: '0.05em' }}>SJSU Analyst Login</div>
        <div style={{ flex: 1, height: '1px', background: 'hsl(var(--border))' }} />
      </div>

      {error && (
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center', padding: '12px', background: 'hsl(var(--destructive)/0.1)', color: 'hsl(var(--destructive))', borderRadius: '6px', fontSize: '13px', marginBottom: '24px' }}>
          <AlertTriangle size={16} />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} autoComplete="on" style={{ display: 'grid', gap: '16px' }}>
        <div>
          <label htmlFor="prototype-email" style={{ display: 'block', marginBottom: '6px', fontSize: '12px', fontWeight: 700 }}>Email</label>
          <input 
            id="prototype-email"
            name="username"
            type="email" 
            autoComplete="username"
            value={email}
            onChange={e => setEmail(e.target.value)}
            style={{ width: '100%', padding: '12px', borderRadius: '6px', border: '1px solid hsl(var(--input))', background: 'hsl(var(--background))' }}
            placeholder="student@sjsu.edu"
          />
        </div>
        
        <div>
          <label htmlFor="prototype-password" style={{ display: 'block', marginBottom: '6px', fontSize: '12px', fontWeight: 700 }}>Password</label>
          <input 
            id="prototype-password"
            name="password"
            type="password" 
            autoComplete="current-password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            style={{ width: '100%', padding: '12px', borderRadius: '6px', border: '1px solid hsl(var(--input))', background: 'hsl(var(--background))' }}
            placeholder="••••••••"
          />
        </div>

        <button className="primary-button" type="submit" style={{ width: '100%', marginTop: '8px', height: '44px' }}>
          Access Prototype <ArrowRight size={16} />
        </button>
      </form>

      <div style={{ marginTop: '24px', textAlign: 'center', fontSize: '12px', color: 'hsl(var(--muted-foreground))' }}>
        Demo Credentials: <br />
        Email: <strong>student@sjsu.edu</strong> <br />
        Password: <strong>demo123</strong>
      </div>
    </div>
  );
}
