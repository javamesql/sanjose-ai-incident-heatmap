import React from 'react';
import { useLocation, Link } from 'wouter';
import { ClipboardCheck, Crosshair, LogOut, FileText, UserRound } from 'lucide-react';
import { useAppContext } from '../context/AppContext';

export function Layout({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, logout, toastMessage } = useAppContext();
  const [location] = useLocation();

  if (location === '/login') {
    return (
      <div className="app-shell" style={{ justifyContent: 'center', alignItems: 'center' }}>
        <main className="main-canvas" style={{ maxWidth: '400px', flex: 'none', margin: '2rem' }}>
          {children}
          {toastMessage && <div className="toast-message" role="status">{toastMessage}</div>}
        </main>
      </div>
    );
  }

  return (
    <div className="app-shell">
      <aside className="app-rail" aria-label="Prototype navigation">
        <div>
          <div className="brand-lockup">
            <div className="brand-mark" aria-hidden="true"><Crosshair size={17} strokeWidth={2.3} /></div>
            <div className="brand-copy">
              <div className="brand-name">SJSU SafeMap</div>
              <div className="brand-subtitle">{isAuthenticated ? 'STUDENT PROTOTYPE' : 'PUBLIC PORTAL'}</div>
            </div>
          </div>
          <div className="rail-kicker">Workspace</div>
          <nav className="rail-nav">
            <Link 
              href="/report" 
              className={`rail-item ${location === '/report' ? 'rail-item-active' : ''}`}
            >
              <FileText size={16} />
              <span>Submit report</span>
            </Link>
            <Link 
              href="/map" 
              className={`rail-item ${location === '/map' ? 'rail-item-active' : ''}`}
            >
              <ClipboardCheck size={16} />
              <span>{isAuthenticated ? 'Signal review' : 'View submission'}</span>
            </Link>
          </nav>
        </div>
        <div>
          {isAuthenticated ? (
            <button 
              className="rail-item" 
              style={{ width: '100%', cursor: 'pointer', background: 'transparent', marginTop: '10px' }} 
              onClick={logout}
            >
              <LogOut size={16} />
              <span>Log out</span>
            </button>
          ) : (
            <Link 
              href="/login"
              className="rail-item" 
              style={{ width: '100%', cursor: 'pointer', background: 'transparent', marginTop: '10px' }} 
            >
              <LogOut size={16} />
              <span>Analyst Login</span>
            </Link>
          )}
          <div className="rail-note" style={{ marginTop: '15px' }}>
            <strong>Fictional prototype</strong>
            No live reports, dispatch connection, or validated predictions.
          </div>
        </div>
      </aside>

      <main className="main-canvas">
        <header className="topbar">
          <div className="topbar-context">
            <span className="context-dot" aria-hidden="true" />
            <span>San José State University · {isAuthenticated ? 'internal prototype' : 'public portal'}</span>
          </div>
          <div className="topbar-role">
            <div className="role-avatar" aria-hidden="true"><UserRound size={15} /></div>
            <span>{isAuthenticated ? 'On-duty analyst / Reporter view' : 'Resident / Visitor view'}</span>
          </div>
        </header>

        {children}
        
        {toastMessage && <div className="toast-message" role="status" data-testid="status-toast">{toastMessage}</div>}
      </main>
    </div>
  );
}
