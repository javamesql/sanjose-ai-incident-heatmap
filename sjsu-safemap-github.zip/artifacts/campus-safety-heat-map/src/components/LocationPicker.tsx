import React, { useRef, useState, KeyboardEvent } from 'react';
import { Check, Search, MapPin } from 'lucide-react';

export type Coordinates = { latitude: number; longitude: number };
type SelectionSource = 'exif' | 'manual' | 'address';
type AddressCandidate = { id: number; label: string; coordinates: Coordinates };

interface LocationPickerProps {
  initialCoordinates?: Coordinates;
  initialSource?: SelectionSource;
  initialAddress?: string;
  onConfirm: (coords: Coordinates, source: SelectionSource, address?: string) => void;
  onCancel: () => void;
}

// Fictional bounding box for SJSU map 760x355
const SJSU_BOUNDS = {
  north: 37.3382,
  south: 37.3312,
  west: -121.8848,
  east: -121.8768
};
const addressCache = new Map<string, AddressCandidate[]>();
let lastGeocodingRequestAt = 0;

function latLngToXY(lat: number, lng: number): { x: number; y: number } {
  const x = ((lng - SJSU_BOUNDS.west) / (SJSU_BOUNDS.east - SJSU_BOUNDS.west)) * 760;
  const y = ((SJSU_BOUNDS.north - lat) / (SJSU_BOUNDS.north - SJSU_BOUNDS.south)) * 355;
  return { x: Math.max(0, Math.min(760, x)), y: Math.max(0, Math.min(355, y)) };
}
function inCampusBounds(coords: Coordinates) {
  return coords.latitude >= SJSU_BOUNDS.south && coords.latitude <= SJSU_BOUNDS.north &&
    coords.longitude >= SJSU_BOUNDS.west && coords.longitude <= SJSU_BOUNDS.east;
}

function xyToLatLng(x: number, y: number): Coordinates {
  const lng = SJSU_BOUNDS.west + (x / 760) * (SJSU_BOUNDS.east - SJSU_BOUNDS.west);
  const lat = SJSU_BOUNDS.north - (y / 355) * (SJSU_BOUNDS.north - SJSU_BOUNDS.south);
  return { latitude: lat, longitude: lng };
}

export function LocationPicker({ initialCoordinates, initialSource, initialAddress, onConfirm, onCancel }: LocationPickerProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const [exactCoordinates, setExactCoordinates] = useState<Coordinates | undefined>(initialCoordinates && inCampusBounds(initialCoordinates) ? initialCoordinates : undefined);
  const [selectionSource, setSelectionSource] = useState<SelectionSource>(initialCoordinates && !inCampusBounds(initialCoordinates) ? 'manual' : initialSource ?? 'manual');
  const [selectedAddress, setSelectedAddress] = useState<string | undefined>(initialCoordinates && !inCampusBounds(initialCoordinates) ? undefined : initialAddress);
  const [replacementSelected, setReplacementSelected] = useState(!initialCoordinates || inCampusBounds(initialCoordinates));
  const [addressQuery, setAddressQuery] = useState('');
  const [addressResults, setAddressResults] = useState<AddressCandidate[]>([]);
  const [searchState, setSearchState] = useState<'idle' | 'loading' | 'error'>('idle');
  const [searchMessage, setSearchMessage] = useState('');
  
  // Default to center if no initial
  const [posXY, setPosXY] = useState<{ x: number; y: number }>(() => {
    if (initialCoordinates && inCampusBounds(initialCoordinates)) {
      return latLngToXY(initialCoordinates.latitude, initialCoordinates.longitude);
    }
    return { x: 380, y: 177 }; // Center
  });

  const handleClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const scaleX = 760 / rect.width;
    const scaleY = 355 / rect.height;
    
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;
    
    setPosXY({ x, y });
    setReplacementSelected(true);
    setExactCoordinates(undefined);
    setSelectionSource('manual');
    setSelectedAddress(undefined);
    setAddressResults([]);
  };

  const handleKeyDown = (e: KeyboardEvent) => {
    const step = 10;
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      setPosXY(p => ({ ...p, y: Math.max(0, p.y - step) }));
      setReplacementSelected(true);
      setExactCoordinates(undefined);
      setSelectionSource('manual');
      setSelectedAddress(undefined);
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      setPosXY(p => ({ ...p, y: Math.min(355, p.y + step) }));
      setReplacementSelected(true);
      setExactCoordinates(undefined);
      setSelectionSource('manual');
      setSelectedAddress(undefined);
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      setPosXY(p => ({ ...p, x: Math.max(0, p.x - step) }));
      setReplacementSelected(true);
      setExactCoordinates(undefined);
      setSelectionSource('manual');
      setSelectedAddress(undefined);
    } else if (e.key === 'ArrowRight') {
      e.preventDefault();
      setPosXY(p => ({ ...p, x: Math.min(760, p.x + step) }));
      setReplacementSelected(true);
      setExactCoordinates(undefined);
      setSelectionSource('manual');
      setSelectedAddress(undefined);
    } else if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      if (replacementSelected) onConfirm(currentCoordinates, selectionSource, selectedAddress);
    }
  };

  const handleConfirm = () => {
    if (replacementSelected) onConfirm(currentCoordinates, selectionSource, selectedAddress);
  };
  const currentCoordinates = !replacementSelected && initialCoordinates
    ? initialCoordinates
    : exactCoordinates ?? xyToLatLng(posXY.x, posXY.y);

  const searchAddress = async () => {
    const query = addressQuery.trim();
    if (!query) {
      setSearchState('error');
      setSearchMessage('Enter a building name or address to search.');
      return;
    }

    const cacheKey = query.toLowerCase();
    const cached = addressCache.get(cacheKey);
    if (cached) {
      setAddressResults(cached);
      setSearchState(cached.length ? 'idle' : 'error');
      setSearchMessage(cached.length ? '' : 'No matching addresses found in the campus map area. Try a more specific address.');
      return;
    }

    setSearchState('loading');
    setSearchMessage('');
    try {
      // Keep requests user-initiated, bounded to the map area, and below Nominatim's
      // public-service rate limit. Results are cached for this browser session.
      const delay = Math.max(0, 1000 - (Date.now() - lastGeocodingRequestAt));
      if (delay) await new Promise(resolve => window.setTimeout(resolve, delay));
      lastGeocodingRequestAt = Date.now();

      const params = new URLSearchParams({
        format: 'jsonv2',
        q: query,
        viewbox: `${SJSU_BOUNDS.west},${SJSU_BOUNDS.north},${SJSU_BOUNDS.east},${SJSU_BOUNDS.south}`,
        bounded: '1',
        limit: '5',
        addressdetails: '0',
      });
      const response = await fetch(`https://nominatim.openstreetmap.org/search?${params}`, {
        headers: { Accept: 'application/json' },
      });
      if (!response.ok) throw new Error('Address search is temporarily unavailable. Try again or select a point on the map.');

      const payload = await response.json() as Array<{ place_id: number; display_name: string; lat: string; lon: string }>;
      const candidates = payload.flatMap((item) => {
        const latitude = Number(item.lat);
        const longitude = Number(item.lon);
        const inMapArea = latitude >= SJSU_BOUNDS.south && latitude <= SJSU_BOUNDS.north &&
          longitude >= SJSU_BOUNDS.west && longitude <= SJSU_BOUNDS.east;
        if (!Number.isFinite(latitude) || !Number.isFinite(longitude) || !inMapArea) return [];
        return [{ id: item.place_id, label: item.display_name, coordinates: { latitude, longitude } }];
      });

      addressCache.set(cacheKey, candidates);
      setAddressResults(candidates);
      setSearchState(candidates.length ? 'idle' : 'error');
      setSearchMessage(candidates.length ? '' : 'No matching addresses found in the campus map area. Try a more specific address.');
    } catch (error) {
      setSearchState('error');
      setSearchMessage(error instanceof Error ? error.message : 'Address search failed. Try again or select a point on the map.');
    }
  };

  const chooseAddress = (candidate: AddressCandidate) => {
    setPosXY(latLngToXY(candidate.coordinates.latitude, candidate.coordinates.longitude));
    setReplacementSelected(true);
    setExactCoordinates(candidate.coordinates);
    setSelectionSource('address');
    setSelectedAddress(candidate.label);
    setAddressQuery(candidate.label);
    setAddressResults([]);
    setSearchState('idle');
    setSearchMessage('');
  };

  return (
    <div className="location-picker-container" style={{ border: '1px solid hsl(var(--border))', borderRadius: '8px', overflow: 'hidden', background: 'hsl(var(--card))' }}>
      <div style={{ padding: '12px 16px', borderBottom: '1px solid hsl(var(--border))', background: 'hsl(var(--muted)/0.3)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div style={{ fontWeight: 600, fontSize: '13px' }}>Select Location</div>
          <div style={{ color: 'hsl(var(--muted-foreground))', fontSize: '11px' }}>Search for an address or click/tap the map. You can adjust the marker with the arrow keys.</div>
          {initialCoordinates && !inCampusBounds(initialCoordinates) && !replacementSelected && <div role="alert" style={{ color: 'hsl(var(--destructive))', fontSize: '11px' }}>The photo coordinates are outside this campus illustration. Confirm their exact value below, or choose a new point on the map. No marker has been moved to the map edge.</div>}
          <div style={{ fontFamily: 'Space Mono, monospace', color: 'hsl(var(--foreground))', fontSize: '11px', marginTop: '4px' }}>
            {currentCoordinates.latitude.toFixed(5)}, {currentCoordinates.longitude.toFixed(5)}
          </div>
          {selectedAddress && <div style={{ fontSize: '11px', marginTop: '4px' }}>{selectedAddress}</div>}
        </div>
      </div>
      {!replacementSelected && initialCoordinates && initialSource === 'exif' && (
        <div style={{ padding: '12px 16px', borderBottom: '1px solid hsl(var(--border))' }}>
          <button type="button" className="secondary-button" onClick={() => onConfirm(initialCoordinates, 'exif')}>
            <Check size={14} /> Confirm exact photo GPS coordinates (outside artwork)
          </button>
        </div>
      )}

      <div style={{ padding: '12px 16px', borderBottom: '1px solid hsl(var(--border))' }}>
        <label htmlFor="location-address-search" style={{ display: 'block', fontSize: '12px', fontWeight: 600, marginBottom: '6px' }}>
          Find an address
        </label>
        <div style={{ display: 'flex', gap: '8px' }}>
          <input
            id="location-address-search"
            type="search"
            value={addressQuery}
            onChange={(event) => setAddressQuery(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === 'Enter') {
                event.preventDefault();
                void searchAddress();
              }
            }}
            placeholder="Building name or street address"
            autoComplete="street-address"
            aria-describedby="address-search-disclosure"
            style={{ minWidth: 0, flex: 1, padding: '9px 10px', border: '1px solid hsl(var(--input))', borderRadius: '6px', background: 'hsl(var(--background))', fontSize: '13px' }}
          />
          <button type="button" className="secondary-button" onClick={() => void searchAddress()} disabled={searchState === 'loading'} style={{ minHeight: '36px' }}>
            <Search size={14} /> {searchState === 'loading' ? 'Searching…' : 'Search'}
          </button>
        </div>
        <p id="address-search-disclosure" style={{ margin: '7px 0 0', color: 'hsl(var(--muted-foreground))', fontSize: '11px', lineHeight: 1.45 }}>
          Address searches are sent to OpenStreetMap’s Nominatim service and limited to the campus area shown. Map data © OpenStreetMap contributors.
        </p>
        {searchMessage && (
          <div role={searchState === 'error' ? 'alert' : 'status'} style={{ marginTop: '8px', color: searchState === 'error' ? 'hsl(var(--destructive))' : 'hsl(var(--muted-foreground))', fontSize: '12px' }}>
            {searchMessage}
          </div>
        )}
        {addressResults.length > 0 && (
          <div role="group" aria-label="Address search results" style={{ display: 'grid', gap: '6px', marginTop: '8px' }}>
            {addressResults.map((candidate) => (
              <button
                key={candidate.id}
                type="button"
                onClick={() => chooseAddress(candidate)}
                className="secondary-button"
                style={{ justifyContent: 'flex-start', height: 'auto', minHeight: '38px', padding: '8px 10px', textAlign: 'left', whiteSpace: 'normal', lineHeight: 1.4 }}
              >
                <MapPin size={14} style={{ flexShrink: 0 }} /> {candidate.label}
              </button>
            ))}
          </div>
        )}
      </div>
      
      <div 
        className="map-visual" 
        style={{ margin: 0, borderRadius: 0, cursor: 'crosshair', height: 'auto', outline: 'none' }}
        tabIndex={0}
        onKeyDown={handleKeyDown}
      >
        <svg 
          ref={svgRef}
          viewBox="0 0 760 355" 
          role="img" 
          aria-label="Interactive campus map picker"
          onClick={handleClick}
          style={{ width: '100%', height: 'auto', display: 'block' }}
        >
          <defs>
            <pattern id="pickerGrid" width="23" height="23" patternUnits="userSpaceOnUse">
              <path d="M 23 0 L 0 0 0 23" fill="none" stroke="#c0c9bb" strokeWidth="0.7" opacity=".6" />
            </pattern>
          </defs>
          <rect width="760" height="355" fill="#d9ddcf" />
          <rect width="760" height="355" fill="url(#pickerGrid)" />
          
          {/* Base map roads/buildings from Map.tsx */}
          <path d="M-15 294 C130 245 165 255 267 275 S466 315 775 235" fill="none" stroke="#f4f0df" strokeWidth="28" opacity=".95" />
          <path d="M-15 294 C130 245 165 255 267 275 S466 315 775 235" fill="none" stroke="#aeb8aa" strokeWidth="1.1" />
          <path d="M140 -10 C155 71 143 142 173 212 S205 299 191 365" fill="none" stroke="#f4f0df" strokeWidth="19" />
          <path d="M140 -10 C155 71 143 142 173 212 S205 299 191 365" fill="none" stroke="#aeb8aa" strokeWidth="1" />
          <path d="M390 -10 C366 66 385 132 361 197 S335 301 348 365" fill="none" stroke="#f4f0df" strokeWidth="16" />
          <path d="M390 -10 C366 66 385 132 361 197 S335 301 348 365" fill="none" stroke="#aeb8aa" strokeWidth="1" />
          <path d="M543 -10 L552 370" stroke="#f4f0df" strokeWidth="22" /><path d="M543 -10 L552 370" stroke="#aeb8aa" strokeWidth="1" />
          <g fill="#b7c4b4" stroke="#8e9f96" strokeWidth="1">
            <path d="M65 54h104v67H65z" /><path d="M195 43h83v92h-83z" /><path d="M306 55h83v69h-83z" />
            <path d="M428 38h86v77h-86z" /><path d="M587 49h108v68H587z" /><path d="M65 158h91v58H65z" />
            <path d="M213 165h116v77H213z" /><path d="M396 157h90v65h-90z" /><path d="M583 155h105v94H583z" />
            <path d="M62 280h84v45H62z" /><path d="M226 285h105v43H226z" /><path d="M402 267h91v64h-91z" />
          </g>
          
          <g fill="#536962" fontFamily="Space Mono, monospace" fontSize="9"><text x="77" y="148">LIBRARY</text><text x="225" y="258">STUDENT UNION</text><text x="397" y="245">PASEO DE SAN CARLOS</text><text x="591" y="270">7TH STREET</text></g>
          
          {/* User Marker */}
          {replacementSelected && <g transform={`translate(${posXY.x}, ${posXY.y})`} style={{ transition: 'transform 0.1s ease-out' }}>
            <circle cx="0" cy="0" r="14" fill="hsl(var(--primary))" opacity="0.2" />
            <circle cx="0" cy="0" r="6" fill="hsl(var(--primary))" stroke="white" strokeWidth="2" />
            <path d="M0 -22 L0 -8 M-22 0 L-8 0 M0 22 L0 8 M22 0 L8 0" stroke="hsl(var(--primary))" strokeWidth="2" strokeLinecap="round" />
          </g>}
        </svg>
      </div>
      
      <div style={{ padding: '12px 16px', display: 'flex', justifyContent: 'flex-end', gap: '8px', borderTop: '1px solid hsl(var(--border))' }}>
        <button type="button" className="secondary-button" onClick={onCancel} style={{ height: '32px', fontSize: '11px' }}>Cancel</button>
        <button type="button" className="primary-button" disabled={!replacementSelected} onClick={handleConfirm} style={{ height: '32px', fontSize: '11px' }}>
          <Check size={14} /> Confirm Location
        </button>
      </div>
    </div>
  );
}
