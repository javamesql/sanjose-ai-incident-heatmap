import React, { type ReactNode, useEffect } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

import { AppProvider, useAppContext } from './context/AppContext';
import { Layout } from './components/Layout';
import Login from './pages/Login';
import Report from './pages/Report';
import MapPage from './pages/Map';

const queryClient = new QueryClient();

function RootRedirect() {
  const [, setLocation] = useLocation();
  const { isAuthenticated } = useAppContext();
  
  useEffect(() => {
    if (isAuthenticated) {
      setLocation('/report');
    } else {
      setLocation('/login');
    }
  }, [isAuthenticated, setLocation]);
  
  return null;
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Layout>
        <Switch>
          <Route path="/" component={RootRedirect} />
          <Route path="/login" component={Login} />
          <Route path="/report" component={Report} />
          <Route path="/map" component={MapPage} />
          <Route component={NotFound} />
        </Switch>
      </Layout>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AppProvider>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </AppProvider>
    </QueryClientProvider>
  );
}

export default App;
