import { Router, type IRouter } from "express";
import { desc } from "drizzle-orm";
import { ListSafetyReportsResponse } from "@workspace/api-zod";
import { db, safetyReportsTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/safety-reports", async (req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(safetyReportsTable)
    .orderBy(desc(safetyReportsTable.submittedAt));

  const reports = rows.map((row) => ({
    id: row.id,
    isDemo: row.isDemo,
    reporterType: row.reporterType,
    privacyMode: row.privacyMode,
    coordinates: {
      latitude: row.latitude,
      longitude: row.longitude,
    },
    locationSource: row.locationSource,
    locationConfirmed: row.locationConfirmed,
    location: row.location,
    incidentDate: row.incidentDate,
    incidentTime: row.incidentTime,
    description: row.description,
    incidentType: row.incidentType,
    moderationStatus: row.moderationStatus,
    priorityStatus: row.priorityStatus,
    moderationReason: row.moderationReason,
    submittedAt: row.submittedAt,
  }));

  req.log.info({ count: reports.length }, "Fetched fictional safety reports");
  res.json(ListSafetyReportsResponse.parse(reports));
});

export default router;