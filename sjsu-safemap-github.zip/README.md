# SJSU SafeMap

A campus-safety reporting prototype for San José State University. The map includes fictional demonstration records; they are sample data, not verified incidents or live safety information.

## Included

- React + Vite web app in `artifacts/campus-safety-heat-map`
- Express API in `artifacts/api-server`
- PostgreSQL / Drizzle schema in `lib/db`
- OpenAPI contract and generated client code in `lib/api-spec`, `lib/api-client-react`, and `lib/api-zod`
- Fictional SJSU sample data in `scripts/seed-safety-reports.sql`

User-submitted reports and uploaded images remain in the current browser's IndexedDB. Only the fictional demonstration records are served from PostgreSQL.

## Run on Replit

1. Import this repository into Replit.
2. Set the `DATABASE_URL` secret for the app's PostgreSQL database.
3. Push the schema:

   ```sh
   pnpm --filter @workspace/db run push
   ```

4. Run the SQL in `scripts/seed-safety-reports.sql` against the development database. It is safe to rerun; existing sample IDs are updated with the same fictional examples.
5. Start the `artifacts/api-server` and `artifacts/campus-safety-heat-map` workflows.

## Check the project

```sh
pnpm install
pnpm run typecheck
```

Do not commit `.env` files or database credentials. Configure secrets in the host environment instead.
